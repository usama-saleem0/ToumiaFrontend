// import React, { useState } from "react";
// import BasicInfo1 from "../BasicInfo1/BasicInfo1";
// import Contacts from "../Contacts/Contacts";
// import Facilities from "../Facilities/Facilities";
// import Rooms from "../Rooms/Rooms";
// import RatePlans from "../RatePlans/RatePlans";
// import Photos from "../Photos/Photos";
// import Policies from "../Policies/Policies";
// import TaxSetting from "../TaxSetting/TaxSetting";
// import BankDetails from "../BankDetails/BankDetails";
// import LegalInfo from "../LegalInfo/LegalInfo";
// import Documents from "../Documents/Documents";
// import Contract from "../Contract/Contract";

// const Steps = () => {
//   const [step, setStep] = useState(0);
//   const totalSteps = [
//     "Basic Info",
//     "Contacts",
//     "Amenities/Facilities",
//     "Room",
//     "Rate Plans",
//     "Photos",
//     "Policies",
//     "Tax Setting",
//     "Bank Details",
//     "Legal Info",
//     "Document",
//     "Contract",
//   ];

//   const steps = [
//     <BasicInfo1 />,
//     <Contacts />,
//     <Facilities />,
//     <Rooms />,
//     <RatePlans />,
//     <Photos />,
//     <Policies />,
//     <TaxSetting />,
//     <BankDetails />,
//     <LegalInfo />,
//     <Documents />,
//     <Contract />,
//   ];

//   const handleNext = () => {
//     if (step < totalSteps.length - 1) setStep(step + 1);
//   };

//   const handlePrev = () => {
//     if (step > 0) setStep(step - 1);
//   };

//   const handleSubmit = () => {
//     console.log("Form submitted");
//   };

//   const goToStep = (index) => {
//     setStep(index);
//   };

//   return (
//     <div className="ar-steps-section">
//       <div className="container">
//         <div className="ar-main-steps">
//           <div className="progress_container">
//             {totalSteps.map((title, index) => (
//               <div key={index} className="step">
//                 <div
//                   className={`circle ${step >= index ? "active" : ""}`}
//                   onClick={() => goToStep(index)}
//                 ></div>
//                 <p className="step-title">{title}</p>
//               </div>
//             ))}
//           </div>

//           <div className="step-content">{steps[step]}</div>

//           <div className="btns">
//             <button
//               className={`${step <= 0 ? "btn-prev disabled" : "btn-prev"}`}
//               onClick={handlePrev}
//               disabled={step <= 0}
//             >
//               Prev
//             </button>

//             {step < totalSteps.length - 1 ? (
//               <button
//                 className={`${
//                   step >= totalSteps.length - 1 ? "disabled" : "btn"
//                 }`}
//                 onClick={handleNext}
//               >
//                 Next
//               </button>
//             ) : (
//               <button className="btn" onClick={handleSubmit}>
//                 Submit
//               </button>
//             )}
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default Steps;

import React, { useState } from "react";
import BasicInfo1 from "../BasicInfo1/BasicInfo1";
import Contacts from "../Contacts/Contacts";
import Facilities from "../Facilities/Facilities";
import Rooms from "../Rooms/Rooms";
import RatePlans from "../RatePlans/RatePlans";
import Photos from "../Photos/Photos";
import Policies from "../Policies/Policies";
import TaxSetting from "../TaxSetting/TaxSetting";
import BankDetails from "../BankDetails/BankDetails";
import LegalInfo from "../LegalInfo/LegalInfo";
import Documents from "../Documents/Documents";
import Contract from "../Contract/Contract";
import BasicInfo from "../BasicInfo/BasicInfo";
import controlimg from "../../../../assets/control/controlimg.png";

import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

import { useDispatch, useSelector } from "react-redux";
import { saveVendorInfo } from "../../../../Redux/Features/VendorSlice";
import Heading from "../../../SidebarHeading/Heading";

const Steps = () => {
  const dispatch = useDispatch();
  const { loading, error } = useSelector((state) => state.vendorinfo); // Access loading and error states

  const [formData, setFormData] = useState({
    // starRating: '',
    // builtYear: '',
    // propertyType: '',
    // chainName: '',
    // numOfRestaurants: '',
    // currency: 'USD', // Default value
    // numOfFloors: '',
    // timezone: '',
    // channelManager: '', // This will hold 'yes' or 'no'
    // streetAddress: '',
    // latitude: '',
    // longitude: '',

    propertyName: "",
    propertyFormerName: "",
    checkinTime: "",
    checkoutTime: "",
    description: "",
    country: "",
    city: "",
    locality: "",
    postalCode: "",

    primaryContactName: "",
    emailAddress: "",
    phoneNumber: "",
    secondaryContactName: "",
    secondaryContactEmail: "",
    emergencyContactInfo: "",

    amenities: "",
    Tour_Pictures: "",

    Roomtype: "",
    Roomsrequired: "",
    RoomDescription: "",
    MaximumOccupancy: "",
    RoomSize: "",
    BedType: "",
    nightprice: "",
    Room_Pictures: "",

    ratePlanName: "",
    rateprice: "",
    mealPlan: "",
    cancellationPolicy: "",
    discountsOrOffers: "",
    ratebedType: "",
    ratepricePerNight: "",
    ratedescription: "",

    Photos_Pictures: "",

    checkInPolicy: "",
    checkOutPolicy: "",
    petPolicy: "",
    smokingPolicy: "",
    parkingPolicy: "",
    cancellationPolicyPolicies: "",

    taxPercentage: "",
    taxType: "",
    cityTax: "",
    otherTaxes: "",

    accountHolderName: "",
    bankName: "",
    accountNumber: "",
    swiftCode: "",
    bankAddress: "",
    taxID: "",

    termsAndConditions: "",
    privacyPolicy: "",
    hotelLicenseNumber: "",
    legalDocuments: "",

    uploadDocuments: "",
    documentTitle: "",
    documentDescription: "",

    contractType: "",
    contractTerms: "",
    contractStartDate: "",
    contractEndDate: "",
    uploadContract: "",
  });

  const handleSubmitall = (e) => {
    e.preventDefault();
    dispatch(saveVendorInfo(formData));
    // Show success or error toast based on the loading and error states
    if (loading) {
      toast.info("Saving...");
    } else if (error) {
      toast.error("Error saving vendor information");
    } else {
      toast.success("Vendor information saved successfully!");
    }
  };

  const [step, setStep] = useState(0);
  const totalSteps = [
    "Basic Info",
    "Contacts",
    "Amenities/Facilities",
    "Room",
    "Rate Plans",
    "Photos",
    "Policies",
    "Tax Setting",
    "Bank Details",
    "Legal Info",
    "Document",
    "Contract",
  ];

  const steps = [
    <BasicInfo1 formData={formData} setFormData={setFormData} />,
    <Contacts formData={formData} setFormData={setFormData} />,
    <Facilities formData={formData} setFormData={setFormData} />,
    <Rooms formData={formData} setFormData={setFormData} />,
    <RatePlans formData={formData} setFormData={setFormData} />,
    <Photos formData={formData} setFormData={setFormData} />,
    <Policies formData={formData} setFormData={setFormData} />,
    <TaxSetting formData={formData} setFormData={setFormData} />,
    <BankDetails formData={formData} setFormData={setFormData} />,
    <LegalInfo formData={formData} setFormData={setFormData} />,
    <Documents formData={formData} setFormData={setFormData} />,
    <Contract formData={formData} setFormData={setFormData} />,
  ];

  const handleNext = () => {
    if (step < totalSteps.length - 1) setStep(step + 1);
  };

  const handlePrev = () => {
    if (step > 0) setStep(step - 1);
  };

  const handleSubmit = () => {
    console.log("Form submitted");
  };

  const goToStep = (index) => {
    setStep(index);
  };

  // const handleNext = () => {
  //   const isFormValid = Object.values(formData).every((value) => value !== '' && value !== null && value !== undefined);

  //   if (isFormValid) {
  //     if (step < totalSteps.length - 1) setStep(step + 1); // Move to next step if form is valid
  //   } else {
  //     toast.error("Please fill in all required fields before proceeding.");
  //   }
  // };

  // const handlePrev = () => {
  //   if (step > 0) setStep(step - 1);
  // };

  // const handleSubmit = () => {
  //   console.log("Form submitted");
  // };

  // const goToStep = (index) => {
  //   setStep(index);
  // };

  return (
    <section className="AddTour-section">
      <div className="main-customer">
        <Heading heading={"Add Property"} controlimg={controlimg} />
        <div className="top-padding-dash-inner-sec">
          {" "}
          <div className="ar-steps-section">
            <div className="container">
              <div className="ar-main-steps">
                <div className="progress_container">
                  {totalSteps.map((title, index) => (
                    <div key={index} className="step">
                      <div
                        className={`circle ${step >= index ? "active" : ""}`}
                        onClick={() => step >= index && goToStep(index)}
                      ></div>
                      <p className="step-title">{title}</p>
                    </div>
                  ))}
                </div>

                <div className="step-content">{steps[step]}</div>

                <div className="btns">
                  <button
                    className={`${
                      step <= 0 ? "btn-prev disabled" : "btn-prev"
                    }`}
                    onClick={handlePrev}
                    disabled={step <= 0}
                  >
                    Prev
                  </button>

                  {step < totalSteps.length - 1 ? (
                    <button
                      className={`${
                        step >= totalSteps.length - 1 ? "disabled" : "btn"
                      }`}
                      onClick={handleNext} // Validation logic inside handleNext
                    >
                      Next
                    </button>
                  ) : (
                    <button className="btn" onClick={handleSubmitall}>
                      Submit
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Steps;
