import React from "react";
import Headerfrom from "../../../../mocks/Headerfrom";
import Partnershipmain from "./Partnershipmain";
import Footer from "../../../../mocks/Footer";

const Partnership = () => {
  return (
    <>
      <Headerfrom />
      <Partnershipmain />
      <Footer />
    </>
  );
};

export default Partnership;
