import React from 'react'
import card1 from "../../assets/Images/Hotels.png"; 

import Slider from "react-slick";

const RecommentedFlights = () => {
    // const settings = {
    //     dots: true,
    //     infinite: true,
    //     speed: 500,
    //     slidesToShow: 3,
    //     slidesToScroll: 3
    // };

    var settings = {
      dots: true,
      infinite: false,
      speed: 500,
      slidesToShow: 3,
      slidesToScroll: 3,
      initialSlide: 0,
      responsive: [
        {
          breakpoint: 1024,
          settings: {
            slidesToShow: 3,
            slidesToScroll: 3,
            infinite: true,
            dots: true
          }
        },
        {
          breakpoint: 600,
          settings: {
            slidesToShow: 2,
            slidesToScroll: 2,
            initialSlide: 2
          }
        },
        {
          breakpoint: 480,
          settings: {
            slidesToShow: 1,
            slidesToScroll: 1
          }
        }
      ]
    };

    
    const cardData = [
        {
          price: "Paris",
          duration: "01 Night",
          title: "Costa Brava",
          description: "$600",
        
          img: card1,
        },


        {
            price: "Paris",
            duration: "01 Night",
            title: "Costa Brava",
            description: "$600",
            img: card1,
          },
        

        {
            price: "Paris",
            duration: "01 Night",
            title: "Costa Brava",
            description: "$600",
          
            img: card1,
          },
          {
            price: "Paris",
            duration: "01 Night",
            title: "Costa Brava",
            description: "$600",
          
            img: card1,
          },
          {
            price: "Paris",
            duration: "01 Night",
            title: "Costa Brava",
            description: "$600",
          
            img: card1,
          },
          {
            price: "Paris",
            duration: "01 Night",
            title: "Costa Brava",
            description: "$600",
          
            img: card1,
          },
          {
            price: "Paris",
            duration: "01 Night",
            title: "Costa Brava",
            description: "$600",
          
            img: card1,
          },
          {
            price: "Paris",
            duration: "01 Night",
            title: "Costa Brava",
            description: "$600",
          
            img: card1,
          },
        // You can duplicate or change the content for the remaining cards
    
    
      
    
    
 

      ];

    return (
        <>
            <div className="recommented--flights">
                <div className="container">
                    <div className="recommented--flight--main">
                        <div className="recommented--flight--main--top">

                            <div className="recommented--flight--main--top--left">

                                <h1>Recommended Hotels</h1>
                                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                            </div>
                           




                        </div>


                        <div className="recommented--flight--main--bottom">
                            <div className="slider-container">
                                <Slider {...settings} className='hello-salider'>
                           
                                {cardData.map((card, index) => (

              <div className="Package-card" key={index}>
                <div className="Package-card-img">
                  <img src={card.img} alt={`Package ${index + 1}`} />
                </div>
                <div className="Package-tital-box">
                  <div className="Person-Package NEW-Paris">
                    <p>{card.price}</p>
                    <p>{card.duration}</p>
                  </div>

<div className="NEW-tiatal-boxing">
<h2>{card.title}</h2>
<h4>{card.description}</h4>
</div>
                

               <div className="View-BTN-BOX">
                <button>View</button>
                <button>Book</button>
               </div>
                </div>
              </div>
            ))}
             
                                </Slider>
                            </div>
                        </div>

                        <div className="recommented--flight--btn-box">
                            <button>View All</button>
                        </div>




                    </div>
                </div>
            </div>
        </>
    )
}

export default RecommentedFlights
