import React from "react";


const Hotelshero = () => {
  // Array of image sources

  return (
    <section className="inner-hero">
      <div className="container">
        <div className="main-inner-hero">
          <div className="inner-hero-tital">
            <h2>Hotels</h2>
            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.
              Lorem Ipsum has been the industry's standard dummy text
              ever since the 1500s,</p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hotelshero;
