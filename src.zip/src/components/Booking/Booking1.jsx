import React from "react";
import booking from "../../assets/Images/booking.png";
import circle from "../../assets/Images/circle.png";
import pay1 from "../../assets/Images/pay1.png";
import pay2 from "../../assets/Images/pay2.png";
import pay3 from "../../assets/Images/pay3.png";
import pay4 from "../../assets/Images/pay4.png";
import pay5 from "../../assets/Images/pay1.png";
import pay6 from "../../assets/Images/pay2.png";
import pay7 from "../../assets/Images/pay3.png";
import pay8 from "../../assets/Images/pay4.png";

const Booking1 = () => {
  return (
    <div className="booking-section">
      <div className="container">
        <div className="main-booking">
          <div className="booking-details-div">
            <div className="booking-img">
              <img src={booking} alt="" />
            </div>
            <div className="booking-details">
              <div>
                <h4>Costa Brava</h4>
                <h6>Return Flight</h6>
              </div>
              <div>
                <p>01 Night</p>
                <h5>$600</h5>
              </div>
            </div>
          </div>
          <div className="pay">
            <h5>Pay Now</h5>
            <div className="pay-divs">
              <div className="pay1">
                <div className="pay-details">
                  <div className="circle-checkbox">
                    <input type="radio" name="payment" id="payWithCard" />
                  </div>
                  <div>
                    <h5>Pay With Card</h5>
                    <div className="pay-cards-img-div">
                      <div className="pay-cards-img">
                        <img src={pay1} alt="Pay Option 1" />
                      </div>
                      <div className="pay-cards-img">
                        <img src={pay2} alt="Pay Option 2" />
                      </div>
                      <div className="pay-cards-img">
                        <img src={pay3} alt="Pay Option 3" />
                      </div>
                      <div className="pay-cards-img">
                        <img src={pay4} alt="Pay Option 4" />
                      </div>
                    </div>
                  </div>
                </div>
                <h5>$600</h5>
              </div>
              <div className="pay1">
                <div className="pay-details">
                  <div className="circle-checkbox">
                    <input type="radio" name="payment" id="payWithCrypto" />
                  </div>
                  <div>
                    <h5>Pay With Crypto</h5>
                    <div className="pay-cards-img-div">
                      <div className="pay-cards2-img">
                        <img src={pay5} alt="Pay Option 5" />
                      </div>
                      <div className="pay-cards2-img">
                        <img src={pay6} alt="Pay Option 6" />
                      </div>
                      <div className="pay-cards2-img">
                        <img src={pay7} alt="Pay Option 7" />
                      </div>
                      <div className="pay-cards2-img">
                        <img src={pay8} alt="Pay Option 8" />
                      </div>
                    </div>
                  </div>
                </div>
                <h5>$600</h5>
              </div>
            </div>
          </div>
          <form>
            {" "}
            <div className="personal">
              <h3>Your Personal Information</h3>
              <div className="inputs">
                <div className="input1-div">
                  <p>First Name</p>
                  <input
                    className="input"
                    type="text"
                    placeholder="City,Distirct or Specific Airpot"
                  />
                </div>
                <div className="input1-div">
                  <p>Last Name</p>
                  <input
                    className="input"
                    type="text"
                    placeholder="City,Distirct or Specific Airpot"
                  />
                </div>
              </div>
              <div className="inputs">
                <div className="input1-div">
                  <p>Email I'd</p>
                  <input
                    className="input"
                    type="text"
                    placeholder="City,Distirct or Specific Airpot"
                  />
                </div>
                <div className="input1-div">
                  <p>Verify Email I'd</p>
                  <input
                    className="input"
                    type="text"
                    placeholder="City,Distirct or Specific Airpot"
                  />
                </div>
              </div>
              <div className="inputs">
                <div className="input1-div">
                  <p>Country Code</p>
                  <select className="input dropdown">
                    <option value="">Select Country Code</option>
                    <option value="+1">+1 (USA)</option>
                    <option value="+44">+44 (UK)</option>
                    <option value="+91">+91 (India)</option>
                  </select>
                </div>
                <div className="input1-div">
                  <p>Phone No#</p>
                  <input
                    className="input"
                    type="text"
                    placeholder="City,Distirct or Specific Airpot"
                  />
                </div>
              </div>
            </div>
            <div className="personal">
              <h3>Your Card Information</h3>
              <div className="inputs">
                <div className="input1-div">
                  <p>Card Type</p>
                  <select className="input">
                    <option value="">Select Card Type</option>
                    <option value="visa">Visa</option>
                    <option value="mastercard">MasterCard</option>
                    <option value="amex">American Express</option>
                  </select>
                </div>
                <div className="input1-div">
                  <p>Card Holder Name</p>
                  <input
                    className="input"
                    type="text"
                    placeholder="Card Holder"
                  />
                </div>
              </div>
              <div className="inputs">
                <div className="input1-div">
                  <p>Card Number</p>
                  <input
                    className="input"
                    type="text"
                    placeholder="Card Number"
                  />
                </div>
                <div className="input1-div">
                  <p>Card Identification Number</p>
                  <input
                    className="input"
                    type="text"
                    placeholder="Card Identification number"
                  />
                </div>
              </div>
              <div className="inputs">
                <div className="input1-div">
                  <p>Expiration Month</p>
                  <select className="input">
                    <option value="">Select Month</option>
                    <option value="01">January</option>
                    <option value="02">February</option>
                    <option value="03">March</option>
                  </select>
                </div>
                <div className="input1-div">
                  <p>Expiration Year</p>
                  <select className="input">
                    <option value="">Select Year</option>
                    <option value="2024">2024</option>
                    <option value="2025">2025</option>
                    <option value="2026">2026</option>
                  </select>
                </div>
              </div>
            </div>
            <div className="personal">
              <h3>Pay with Crypto</h3>
              <div className="inputs">
                <div className="input1-div">
                  <p>First Name</p>
                  <input
                    className="input"
                    type="text"
                    placeholder="First Name"
                  />
                </div>
                <div className="input1-div">
                  <p>Last Name</p>
                  <input
                    className="input"
                    type="text"
                    placeholder="Last Name"
                  />
                </div>
              </div>

              <div className="inputs">
                <div className="input1-div">
                  <p>Country Code</p>
                  <input className="input" type="text" placeholder="Code" />
                </div>
                <div className="input1-div">
                  <p>Phone Number</p>
                  <input className="input" type="text" placeholder="number" />
                </div>
              </div>
              <div className="inputs">
                <div className="input1-div">
                  <p>Address</p>
                  <input
                    className="input"
                    type="text"
                    placeholder="address enter"
                  />
                </div>
                <div className="input1-div">
                  <p>City</p>
                  <input className="input" type="text" placeholder="enter" />
                </div>
              </div>
              <div className="inputs">
                <div className="input1-div">
                  <p>Country</p>
                  <select className="input">
                    <option value="">Select Country</option>
                    <option value="us">United States</option>
                    <option value="uk">United Kingdom</option>
                    <option value="india">India</option>
                  </select>
                </div>
                <div className="input1-div">
                  <p>Zip Code</p>
                  <input className="input" type="text" placeholder="zip code" />
                </div>
              </div>
            </div>
            <div className="submit-btns">
              <button className="cancel-btn">Cancel</button>
              <button className="proceed-btn">Proceed</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default Booking1;
