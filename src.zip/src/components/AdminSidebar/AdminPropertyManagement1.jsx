import React from "react";
import Heading from "../SidebarHeading/Heading";
import controlimg from "../../assets/control/controlimg.png";
import { Tab, Tabs, TabList, TabPanel } from "react-tabs";
import "react-tabs/style/react-tabs.css"; // Import react-tabs CSS
import card1 from "../../assets/dashboard/property.png";
import update from "../../assets/dashboard/update.png";
import name from "../../assets/dashboard/name.png";
import phone from "../../assets/dashboard/phone.png";
import email from "../../assets/dashboard/email.png";
import Arrow from "../../assets/dashboard/Arrow.png";
import { useNavigate } from "react-router-dom";

const AdminPropertyManagement1 = () => {
  const navigate = useNavigate();
  const cardData = [
    {
      name: "John Smith",
      phone: "+000 2222 3333",
      gmail: "dummy@gmail.com",
      title: "Costa Brava",
      img: card1,
    },
    {
      name: "John Smith",
      phone: "+000 2222 3333",
      gmail: "dummy@gmail.com",
      title: "Costa Brava",
      img: card1,
    },
    {
      name: "John Smith",
      phone: "+000 2222 3333",
      gmail: "dummy@gmail.com",
      title: "Costa Brava",
      img: card1,
    },
    {
      name: "John Smith",
      phone: "+000 2222 3333",
      gmail: "dummy@gmail.com",
      title: "Costa Brava",
      img: card1,
    },
    {
      name: "John Smith",
      phone: "+000 2222 3333",
      gmail: "dummy@gmail.com",
      title: "Costa Brava",
      img: card1,
    },
    {
      name: "John Smith",
      phone: "+000 2222 3333",
      gmail: "dummy@gmail.com",
      title: "Costa Brava",
      img: card1,
    },
  ];

  return (
    <section className="AddTour-section">
      <div className="main-customer">
        <Heading heading={"Property Mangement"} controlimg={controlimg} />
        <div className="top-padding-dash-inner-sec">
          <div className="admin-dash-inner-blow-head">
            <div className="AddTour-main-box">
              <div className="main-Flights1">
                <div className="Flights1-box" style={{ gap: "40px 0" }}>
                  {cardData.map((card, index) => (
                    <div className="dashboard2-card" key={index}>
                      <div style={{ width: "100%" }}>
                        <img style={{ width: "100%" }} src={card1} alt="" />
                      </div>
                      <div className="property-card-detail">
                        <h4>{card.title}</h4>
                        {/* <div className="update-large-img-ar">
                          <img src={update} alt="" />
                        </div> */}
                      </div>
                      <div className="property-detail-div-ar">
                        <div className="property-detail-ar">
                          <div>
                            <img src={name} alt="" />
                          </div>
                          <h6>{card.name}</h6>
                        </div>
                        <div className="property-detail-ar">
                          <div>
                            <img src={phone} alt="" />
                          </div>
                          <h6>{card.phone}</h6>
                        </div>
                        <div className="property-detail-ar">
                          <div>
                            <img src={email} alt="" />
                          </div>
                          <h6>{card.gmail}</h6>
                        </div>
                      </div>
                      <div>
                        <button
                          onClick={() =>
                            navigate("/Admin_dashboard/AdminPropertyinner")
                          }
                          className="view-btn-property-ar"
                        >
                          {" "}
                          <p>View</p>
                          <div className="arrow-view-ar">
                            {" "}
                            <img src={Arrow} alt="" />
                          </div>
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AdminPropertyManagement1;
