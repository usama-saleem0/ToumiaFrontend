import {  React, useState } from "react";
import { useDispatch, useSelector } from "react-redux";

import right from '../../assets/Images/Gp6.png'


const About2 = () => {






  return (
    <>
    <section className='sec-2'>
        <div className="container">
            <div className="main-sec-2">
                <div className="main-sec-2-child-1">
                    <h1>32K</h1>
                    <h2>Overall Booking</h2>
                </div>
                <div className="main-sec-2-child-1">
                    <h1>25+</h1>
                    <h2>Years Successfully</h2>
                </div>
                <div className="main-sec-2-child-1">
                    <h1>45K</h1>
                    <h2>Happly Client</h2>
                </div>
                <div className="main-sec-2-child-1">
                    <h1>32K</h1>
                    <h2>Countries We Work</h2>
                </div>
            </div>
        </div>

    </section>
    </>
  );
};

export default About2;

