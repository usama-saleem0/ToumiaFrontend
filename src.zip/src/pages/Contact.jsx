import React, { useEffect } from "react";
import Header from "../mocks/Header";
import Abouthero from "../components/inner-hero/Abouthero";
import Footer from "../mocks/Footer";
import Contacthero from "../components/inner-hero/Contacthero";
import Contact1 from "../components/Contact/Contact1";




const Contact  = () => {









  return (
    <>
      <Header />
      <Contacthero/>
      <Contact1/>
      <Footer/>
    </>
  );
};

export default Contact;
