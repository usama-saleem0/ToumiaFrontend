import React, { useEffect } from "react";
import Header from "../mocks/Header";
import Footer from "../mocks/Footer";
import Detailshero from "../components/inner-hero/Detailshero";
import FlightDetails1 from "../components/Flights-Details/FlightsDetails1";




const FlightDetails  = () => {









  return (
    <>
      <Header />
<Detailshero/>

<FlightDetails1/>
      <Footer/>
    </>
  );
};

export default FlightDetails;
