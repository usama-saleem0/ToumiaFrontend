import React, { useEffect } from "react";
import Header from "../mocks/Header";
import Bookingshero from "../components/inner-hero/Bookinghero";
import Footer from "../mocks/Footer";
import Booking1 from "../components/Booking/Booking1";




const Booking  = () => {









  return (
    <>
      <Header />
   <Bookingshero/>
   <Booking1/>
      <Footer/>
    </>
  );
};

export default Booking;
