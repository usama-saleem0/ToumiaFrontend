import React, { useEffect } from "react";
import Header from "../mocks/Header";
import Footer from "../mocks/Footer";
import HotelDetailshero from "../components/inner-hero/HotelDetailshero";
import HotelDetails1 from "../components/Flights-Details/HotelDetails";





const HotelDetails  = () => {









  return (
    <>
      <Header />
<HotelDetailshero/>
<HotelDetails1/>
      <Footer/>
    </>
  );
};

export default HotelDetails;
